import { Github, Linkedin, Mail, Instagram } from "lucide-react";
import { siteConfig } from "@/data/site";

const socialLinks = [
  { label: "GitHub", href: siteConfig.social.github, icon: Github },
  { label: "LinkedIn", href: siteConfig.social.linkedin, icon: Linkedin },
  { label: "Email", href: siteConfig.social.email, icon: Mail },
  { label: "Instagram", href: siteConfig.social.instagram, icon: Instagram },
];

export function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-8 sm:flex-row sm:justify-between sm:px-6 lg:px-8">
        <p className="font-mono text-xs text-ink-faint">
          © {new Date().getFullYear()} {siteConfig.name}. Built for the field, not the resume.
        </p>

        <ul className="flex items-center gap-4">
          {socialLinks.map(({ label, href, icon: Icon }) => (
            <li key={label}>
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="text-ink-muted transition-colors hover:text-primary"
              >
                <Icon className="h-5 w-5" aria-hidden="true" />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </footer>
  );
}
