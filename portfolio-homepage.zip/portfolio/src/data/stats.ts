import { FolderGit2, Flag, Award, Clock } from "lucide-react";
import type { Stat } from "@/types";

export const stats: Stat[] = [
  {
    id: "projects",
    label: "Projects Completed",
    value: 12,
    suffix: "+",
    icon: FolderGit2,
  },
  {
    id: "ctf",
    label: "CTF Challenges Solved",
    value: 87,
    suffix: "+",
    icon: Flag,
  },
  {
    id: "certs",
    label: "Certificates Earned",
    value: 6,
    icon: Award,
  },
  {
    id: "years",
    label: "Years Learning IT",
    value: 3,
    icon: Clock,
  },
];
