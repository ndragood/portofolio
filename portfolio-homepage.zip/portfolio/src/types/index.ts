import type { LucideIcon } from "lucide-react";

export interface Stat {
  id: string;
  label: string;
  value: number;
  suffix?: string;
  icon: LucideIcon;
}

export interface Skill {
  id: string;
  name: string;
  icon: LucideIcon;
}

export type ProjectStatus = "completed" | "in-progress" | "archived";

export interface Project {
  id: string;
  slug: string;
  title: string;
  description: string;
  stack: string[];
  status: ProjectStatus;
  href: string;
}
