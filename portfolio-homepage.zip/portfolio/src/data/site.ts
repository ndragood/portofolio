/**
 * Single source of truth for personal details.
 * Replace these placeholder values with your own — nothing else in the
 * homepage components needs to change.
 */
export const siteConfig = {
  name: "Raka Pratama",
  role: "Cyber Security Student",
  tagline:
    "Focused on Security Operations, Network Security, Threat Detection, and Ethical Hacking.",
  location: "Cikarang, West Java, Indonesia",
  resumeUrl: "/resume.pdf",
  nav: [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Skills", href: "/skills" },
    { label: "Projects", href: "/projects" },
    { label: "Certifications", href: "/certifications" },
    { label: "Writeups", href: "/writeups" },
    { label: "Contact", href: "/contact" },
  ],
  social: {
    github: "https://github.com/yourusername",
    linkedin: "https://linkedin.com/in/yourusername",
    email: "mailto:you@example.com",
    instagram: "https://instagram.com/yourusername",
  },
};
