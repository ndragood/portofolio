"use client";

import { motion } from "framer-motion";
import { featuredSkills } from "@/data/skills";

export function FeaturedSkills() {
  return (
    <section aria-labelledby="featured-skills-heading" className="border-b border-line">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-10 flex items-baseline justify-between">
          <h2
            id="featured-skills-heading"
            className="font-display text-2xl font-semibold text-ink sm:text-3xl"
          >
            Core Toolkit
          </h2>
          <span className="font-mono text-xs uppercase tracking-wide text-ink-faint">
            8 / loaded
          </span>
        </div>

        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {featuredSkills.map((skill, i) => {
            const Icon = skill.icon;
            return (
              <motion.li
                key={skill.id}
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.35, delay: i * 0.04 }}
              >
                <div className="flex items-center gap-3 rounded-lg border border-line bg-surface px-4 py-4 transition-colors hover:border-primary/40">
                  <Icon className="h-5 w-5 shrink-0 text-secondary" aria-hidden="true" />
                  <span className="text-sm font-medium text-ink">{skill.name}</span>
                </div>
              </motion.li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
