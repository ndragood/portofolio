import {
  Terminal,
  Code2,
  Network,
  Radar,
  Waves,
  Bug,
  Container,
  MonitorCheck,
} from "lucide-react";
import type { Skill } from "@/types";

export const featuredSkills: Skill[] = [
  { id: "linux", name: "Linux", icon: Terminal },
  { id: "python", name: "Python", icon: Code2 },
  { id: "networking", name: "Networking", icon: Network },
  { id: "nmap", name: "Nmap", icon: Radar },
  { id: "wireshark", name: "Wireshark", icon: Waves },
  { id: "burp", name: "Burp Suite", icon: Bug },
  { id: "docker", name: "Docker", icon: Container },
  { id: "siem", name: "SIEM", icon: MonitorCheck },
];
