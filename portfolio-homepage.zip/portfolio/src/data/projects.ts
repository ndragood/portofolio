import type { Project } from "@/types";

export const featuredProjects: Project[] = [
  {
    id: "1",
    slug: "network-vulnerability-scanner",
    title: "Network Vulnerability Scanner",
    description:
      "A Python-based scanner that automates host discovery, port scanning, and CVE lookups, then generates a prioritized risk report for each target on the network.",
    stack: ["Python", "Nmap", "Sockets", "CVE API"],
    status: "completed",
    href: "/projects/network-vulnerability-scanner",
  },
  {
    id: "2",
    slug: "soc-log-analyzer",
    title: "SOC Log Analyzer",
    description:
      "A log ingestion pipeline that parses firewall and auth logs, flags anomalous login patterns, and surfaces them on a lightweight triage dashboard.",
    stack: ["Python", "Pandas", "ELK Stack", "Docker"],
    status: "completed",
    href: "/projects/soc-log-analyzer",
  },
  {
    id: "3",
    slug: "packet-traffic-visualizer",
    title: "Packet Traffic Visualizer",
    description:
      "A Wireshark-driven packet capture tool paired with a web dashboard that visualizes protocol breakdowns and flags suspicious traffic spikes in real time.",
    stack: ["Wireshark", "Python", "Next.js", "WebSockets"],
    status: "in-progress",
    href: "/projects/packet-traffic-visualizer",
  },
];
