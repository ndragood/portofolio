"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, ShieldCheck } from "lucide-react";
import { siteConfig } from "@/data/site";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-void/80 backdrop-blur-md">
      <nav
        aria-label="Primary"
        className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8"
      >
        <Link
          href="/"
          className="group flex items-center gap-2 font-display text-base font-semibold tracking-tight text-ink"
        >
          <ShieldCheck
            className="h-5 w-5 text-primary transition-transform group-hover:scale-110"
            aria-hidden="true"
          />
          <span>
            {siteConfig.name.split(" ")[0]}
            <span className="text-primary">.</span>
            {siteConfig.name.split(" ").slice(1).join(" ")}
          </span>
        </Link>

        {/* Desktop nav */}
        <ul className="hidden items-center gap-7 md:flex">
          {siteConfig.nav.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className="font-mono text-[13px] uppercase tracking-wide text-ink-muted transition-colors hover:text-primary"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="hidden md:block">
          <a
            href={siteConfig.resumeUrl}
            download
            className="rounded-md border border-primary/40 px-4 py-2 font-mono text-[13px] uppercase tracking-wide text-primary transition-colors hover:bg-primary/10"
          >
            Download CV
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          className="inline-flex items-center justify-center rounded-md p-2 text-ink md:hidden"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile nav panel */}
      <div
        id="mobile-menu"
        className={cn(
          "overflow-hidden border-t border-line bg-void transition-[max-height] duration-300 md:hidden",
          open ? "max-h-96" : "max-h-0"
        )}
      >
        <ul className="flex flex-col gap-1 px-4 py-3">
          {siteConfig.nav.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                onClick={() => setOpen(false)}
                className="block rounded px-2 py-2.5 font-mono text-sm uppercase tracking-wide text-ink-muted hover:bg-surface hover:text-primary"
              >
                {item.label}
              </Link>
            </li>
          ))}
          <li className="pt-2">
            <a
              href={siteConfig.resumeUrl}
              download
              className="block rounded-md border border-primary/40 px-3 py-2.5 text-center font-mono text-sm uppercase tracking-wide text-primary"
            >
              Download CV
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
